# multi-STmodel
A multivariate spatiotemporal model for tracking COVID-19 incidence and death rates in socially vulnerable populations

# Reference
Neelon B, Wen C-C, Benjamin-Neelon SE (2023). "A multivariate spatiotemporal model for tracking COVID-19 incidence and death rates in socially vulnerable populations". Journal of Applied Statistics, 50, 1812-1835.
